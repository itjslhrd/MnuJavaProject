//흐름제어
public class Exam_15 {
	public static void main(String[] args) {
		int score = 70;
		//점수가 80이상이면 "합격" 출력
		if(score>=80) {
			System.out.println("합격" );
		}else {
			System.out.println("불합격" );
		}
		System.out.print("프로그램을 종료합나다." );
	}

}
