
public class Exam_06 {
	public static void main(String[] args) {
		System.out.print("AAAAA");
		System.out.print("\n");
		//System.out.println();
		
		System.out.print("AAAAA\n");
		System.out.print("AAAAA" + "\n");
		
		System.out.println("AAAAA");
		System.out.println();

	}

}
